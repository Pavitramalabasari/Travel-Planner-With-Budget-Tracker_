// Fetch the logged-in user's token
const token = localStorage.getItem("token");

// Handle trip creation
document.getElementById("create-trip-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  
  const title = document.getElementById("title").value;
  const destination = document.getElementById("destination").value;
  const startDate = document.getElementById("startDate").value;
  const endDate = document.getElementById("endDate").value;
  const budget = document.getElementById("budget").value;

  const response = await fetch("/api/trip/create", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`, // Include token for authentication
    },
    body: JSON.stringify({
      title,
      destination,
      startDate,
      endDate,
      budget
    }),
  });

  const data = await response.json();
  if (response.ok) {
    alert("Trip created successfully!");
  } else {
    alert(`Error: ${data.message}`);
  }
});
