const jwt = require("jsonwebtoken");

const authenticate = (req, res, next) => {
  const token = req.header("Authorization")?.replace("Bearer ", ""); // Extract token from header

  if (!token) {
    return res.status(401).json({ message: "Access denied. No token provided." });
  }

  try {
    const decoded = jwt.verify(token, "your_jwt_secret_key"); // Verify token with same secret
    req.userId = decoded.userId; // Attach userId to request
    next();
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "Invalid token." });
  }
};

module.exports = authenticate;
