const express = require('express');
const Trip = require('../models/Trip');
const Expense = require('../models/expense');
const axios = require('axios'); // For making API calls to fetch places like restaurants and hotels
require('dotenv').config(); // To load environment variables from .env file
const router = express.Router();

// Google API Key from environment variables
const GOOGLE_API_KEY = 'AIzaSyBnvwY_bw4hAHfOf_afIysSZqc2VMDJhvo'; // Update with your API key

// Route to get trip details by tripId
router.get('/:tripId', async (req, res) => {
  const { tripId } = req.params;

  try {
    const trip = await Trip.findOne({ tripId });

    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    // Return trip data (including destination) to frontend
    res.json(trip);
  } catch (error) {
    console.error('Error fetching trip:', error);
    res.status(500).json({ message: 'Server error while fetching trip.' });
  }
});

// Route to get restaurants and hotels based on destination
router.get('/places/:destination', async (req, res) => {
  const { destination } = req.params;

  try {
    // Use a public API (e.g., Google Places API) to fetch restaurants and hotels based on the destination
    const response = await axios.get(`https://maps.googleapis.com/maps/api/place/textsearch/json?query=restaurants+and+hotels+in+${destination}&key=${GOOGLE_API_KEY}`);
    
    const places = response.data.results;
    const restaurants = places.filter(place => place.types.includes('restaurant'));
    const hotels = places.filter(place => place.types.includes('lodging'));

    // Return top 5 restaurants and hotels
    res.json({
      restaurants: restaurants.slice(0, 5),
      hotels: hotels.slice(0, 5),
    });
  } catch (error) {
    console.error('Error fetching places:', error);
    res.status(500).json({ message: 'Error fetching places from Google API' });
  }
});

// Route to create an expense and update the budget
router.post('/create', async (req, res) => {
  const { tripId, transportationMode, stayingAmount, otherCosts, totalAmount } = req.body;

  if (!tripId || !transportationMode || !stayingAmount || !otherCosts || !totalAmount) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  try {
    const trip = await Trip.findOne({ tripId }).select('budget');

    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    // Check if the total amount exceeds the budget
    if (totalAmount > trip.budget) {
      return res.status(400).json({ message: 'Insufficient budget to cover expenses.' });
    }

    // Calculate the new remaining budget
    const remainingBudget = trip.budget - totalAmount;

    // Update the trip's budget
    trip.budget = remainingBudget;
    await trip.save();

    // Create and save the expense
    const newExpense = new Expense({
      tripId,
      transportationMode,
      transportationCost: totalAmount - (stayingAmount + otherCosts),
      stayingAmount,
      otherCosts,
      totalAmount,
    });

    await newExpense.save();

    res.status(201).json({
      message: 'Expense created successfully! Budget updated.',
      expense: newExpense,
      remainingBudget: remainingBudget,
    });
  } catch (error) {
    console.error('Error creating expense:', error);
    res.status(500).json({ message: 'Server error while creating expense.' });
  }
});

module.exports = router;
