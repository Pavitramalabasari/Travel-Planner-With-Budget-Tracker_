const express = require('express');
const Expense = require('../models/expense');
const Trip = require('../models/Trip');
const router = express.Router();

// GET request to check if expenses exist for a given tripId
router.get('/:tripId', async (req, res) => {
  try {
    const { tripId } = req.params;

    // Check if the trip exists
    const trip = await Trip.findOne({ tripId });

    if (!trip) {
      return res.status(404).json({ message: 'Trip ID does not exist.' });
    }

    // Find all expenses for the given tripId
    const expenses = await Expense.find({ tripId });

    if (expenses.length === 0) {
      return res.status(404).json({ message: 'No expenses recorded for this trip.' });
    }

    // Calculate the grand total amount (sum of totalAmount)
    const grandTotal = expenses.reduce((total, expense) => total + expense.totalAmount, 0);

    // Count how many times the trip has been used
    const usageCount = expenses.length;

    // Prepare response for each expense related to the trip
    const expensesDetails = expenses.map(expense => ({
      username: req.session.username || 'Guest',  // Ensure username is available or default to 'Guest'
      tripId: expense.tripId,
      tripTitle: trip.title,
      source: trip.source,
      destination: trip.destination,
      originalBudget: trip.originalBudget,
      currentBudget: trip.budget,  // Include the current budget of the trip
      transportationMode: expense.transportationMode,
      transportationAmount: expense.transportationCost,
      stayingAmount: expense.stayingAmount,  // Updated field
      otherCosts: expense.otherCosts,  // Updated field
      totalAmount: expense.totalAmount
    }));

    return res.status(200).json({
      usageCount,
      grandTotal,  // Send the grand total amount in the response
      expensesDetails
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error retrieving the expense status.' });
  }
});

module.exports = router;
