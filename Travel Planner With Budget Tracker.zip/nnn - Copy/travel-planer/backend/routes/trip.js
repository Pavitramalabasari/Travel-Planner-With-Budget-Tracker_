const express = require('express');
const axios = require('axios');
const Trip = require('../models/Trip');
const Expense = require('../models/expense'); // Assuming Expense model exists
const router = express.Router();

// Replace these API keys with environment variables for better security
const GOOGLE_API_KEY = 'AIzaSyA6hH2h-a8Vzd31BzWMSCX_MWA-9yYjBGU';
const PLACES_API_KEY = 'AIzaSyBnvwY_bw4hAHfOf_afIysSZqc2VMDJhvo';

// Middleware to check user authentication
const checkAuth = (req, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: 'Unauthorized. Please log in.' });
  }
  next();
};

// Function to generate a random 5-digit Trip ID
const generateTripId = async () => {
  let tripId;
  let isUnique = false;

  while (!isUnique) {
    tripId = Math.floor(10000 + Math.random() * 90000).toString(); // Generate random 5-digit ID
    const existingTrip = await Trip.findOne({ tripId });
    if (!existingTrip) {
      isUnique = true; // Ensure uniqueness
    }
  }

  return tripId;
};

// Fetch tourist places for the destination
const fetchTouristPlaces = async (destination) => {
  try {
    const response = await axios.get('https://maps.googleapis.com/maps/api/place/textsearch/json', {
      params: {
        query: `tourist attractions in ${destination}`,
        key: PLACES_API_KEY,
      }
    });
    return response.data.results || [];
  } catch (error) {
    console.error('Error fetching tourist places:', error.message);
    return [];
  }
};

// Fetch tourist places dynamically as the user types
router.get('/tourist-places', async (req, res) => {
  const { destination } = req.query;

  if (!destination) {
    return res.status(400).json({ message: 'Destination is required.' });
  }

  try {
    const touristPlaces = await fetchTouristPlaces(destination);
    res.status(200).json({ touristPlaces });
  } catch (error) {
    console.error('Error fetching tourist places:', error.message);
    res.status(500).json({ message: 'Error fetching tourist places. Please try again.' });
  }
});

// Create trip route
router.post('/create', checkAuth, async (req, res) => {
  const { source, destination, startDate, endDate, budget } = req.body;

  if (!source || !destination || !startDate || !endDate || !budget) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  if (new Date(startDate) >= new Date(endDate)) {
    return res.status(400).json({ message: 'End date must be after the start date.' });
  }

  try {
    const tripId = await generateTripId();

    const distanceResponse = await axios.get('https://maps.googleapis.com/maps/api/distancematrix/json', {
      params: {
        origins: source,
        destinations: destination,
        key: GOOGLE_API_KEY,
      }
    });

    const distanceData = distanceResponse.data;

    if (distanceData.status !== 'OK') {
      return res.status(400).json({ message: `Failed to get distance data: ${distanceData.error_message || 'Unknown error'}` });
    }

    const distance = distanceData.rows[0]?.elements[0]?.distance?.text || 'Unknown';
    const duration = distanceData.rows[0]?.elements[0]?.duration?.text || 'Unknown';

    const touristPlaces = await fetchTouristPlaces(destination);

    const newTrip = new Trip({
      userId: req.session.userId,
      tripId,
      source,
      destination,
      startDate,
      endDate,
      budget,
      originalBudget: budget,
      distance,
      duration,
      touristPlaces,
    });

    await newTrip.save();

    res.status(201).json({
      message: 'Trip created successfully!',
      tripId,
      trip: newTrip,
    });
  } catch (error) {
    console.error('Error creating trip:', error.message);
    res.status(500).json({ message: 'Server error while creating the trip.', error: error.message });
  }
});

// View trips route
router.get('/view', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: 'Unauthorized. Please log in.' });
  }

  try {
    const trips = await Trip.find({ userId: req.session.userId }).sort({ startDate: 1 });
    res.status(200).json(trips);
  } catch (error) {
    console.error('Error fetching trips:', error);
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// Update trip route
router.put('/update/:id', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: 'Unauthorized. Please log in.' });
  }

  const { source, destination, startDate, endDate, budget } = req.body;

  try {
    const trip = await Trip.findById(req.params.id);
    if (!trip || trip.userId.toString() !== req.session.userId) {
      return res.status(404).json({ message: 'Trip not found or unauthorized.' });
    }

    trip.source = source || trip.source;
    trip.destination = destination || trip.destination;
    trip.startDate = startDate || trip.startDate;
    trip.endDate = endDate || trip.endDate;
    trip.budget = budget || trip.budget;

    await trip.save();

    res.status(200).json({ message: 'Trip updated successfully!', trip });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error.' });
  }
});

// Fetch trip details by ID
router.get('/:id', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: 'Unauthorized. Please log in.' });
  }

  try {
    const trip = await Trip.findById(req.params.id);
    if (!trip || trip.userId.toString() !== req.session.userId) {
      return res.status(404).json({ message: 'Trip not found or unauthorized.' });
    }

    res.status(200).json(trip);
  } catch (error) {
    console.error('Error fetching trip:', error);
    res.status(500).json({ message: 'Server error.' });
  }
});

// Delete trip route
// Delete trip route
router.delete('/delete/:id', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: 'Unauthorized. Please log in.' });
  }

  try {
    const trip = await Trip.findById(req.params.id);
    if (!trip) {
      return res.status(404).json({ message: 'Trip not found.' });
    }

    // Check if the current user is authorized to delete this trip
    if (trip.userId.toString() !== req.session.userId) {
      return res.status(403).json({ message: 'You do not have permission to delete this trip.' });
    }

    // Delete associated expenses for this trip
    await Expense.deleteMany({ tripId: trip.tripId });  // Assuming 'tripId' is the field linking Expense to Trip

    // Delete the trip
    await Trip.findByIdAndDelete(req.params.id);

    res.status(200).json({ message: 'Trip and associated expenses deleted successfully.' });
  } catch (error) {
    console.error('Error deleting trip:', error);
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// tripRoutes.js



// Endpoint to fetch all active trips
router.get('/trips', async (req, res) => {
  try {
    const trips = await Trip.find(); // You can filter trips based on userId or other criteria if needed
    res.status(200).json(trips); // Return trips as JSON
  } catch (error) {
    console.error('Error fetching trips:', error);
    res.status(500).json({ message: 'Error fetching trips.' });
  }
});

module.exports = router;
