const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// Import Routes
const authRoutes = require('./routes/auth');
const tripRoutes = require('./routes/trip');
const expenseRoutes = require('./routes/expense');
const statusRoutes = require('./routes/status');  // Import the status route

// Middleware
app.use(bodyParser.json());
app.use(cors({
  origin: "http://localhost:3000", // Update this if your React frontend runs on a different port
  credentials: true,  // Allow cookies
}));

// Session middleware
app.use(session({
  secret: 'your_session_secret_key',
  resave: false,
  saveUninitialized: true,
  cookie: {
    secure: false, // Set to true if you're using HTTPS
    httpOnly: true,
    maxAge: 60 * 60 * 1000 // 1 hour session expiration
  }
}));

// Serve static frontend (production build of React)
app.use(express.static(path.join(__dirname, '../frontend')));  // Make sure the build path is correct

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/trip', tripRoutes);
app.use('/api/expense', expenseRoutes); 
app.use('/api/status', statusRoutes);  // Use status route

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/New', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.once('open', () => {
  console.log('Connected to MongoDB');
});

// Global Error Handler (improve with specific error messages)
app.use((err, req, res, next) => {
  console.error(err.stack || err);

  if (err.name === 'ValidationError') {
    return res.status(400).json({ message: 'Validation error occurred.' });
  }

  if (err.name === 'CastError') {
    return res.status(400).json({ message: 'Invalid data format.' });
  }

  res.status(500).json({ message: 'Something went wrong, please try again later.' });
});

// Start the server
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
