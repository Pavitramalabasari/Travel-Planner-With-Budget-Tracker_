const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the expense schema
const expenseSchema = new Schema({
  tripId: {
    type: String,
    required: true,
    ref: 'Trip',  // Reference to the Trip model
  },
  transportationMode: {
    type: String,
    required: true,
    enum: ['bus', 'train', 'flight'],  // Transportation modes
  },
  transportationCost: {
    type: Number,
    required: true,
  },
  stayingAmount: {
    type: Number,
    required: true,
  },
  otherCosts: {
    type: Number,
    required: true,
  },
  totalAmount: {
    type: Number,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Expense = mongoose.model('Expense', expenseSchema);

module.exports = Expense;
