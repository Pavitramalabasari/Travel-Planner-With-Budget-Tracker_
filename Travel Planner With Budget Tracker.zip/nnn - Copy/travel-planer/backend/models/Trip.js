const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  tripId: { type: String, unique: true, required: true }, // Add this field for the 5-digit Trip ID
  source: { type: String, required: true },
  destination: { type: String, required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  budget: { type: Number, required: true }, // Current budget (modifiable)
  originalBudget: { type: Number, required: true }, // Initial budget (immutable)
  distance: { type: String }, // Optional, based on the API response
  duration: { type: String }, // Optional, based on the API response
}, { timestamps: true });

module.exports = mongoose.model('Trip', tripSchema);
