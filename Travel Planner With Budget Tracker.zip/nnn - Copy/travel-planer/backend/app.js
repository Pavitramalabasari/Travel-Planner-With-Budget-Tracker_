const express = require('express');
const axios = require('axios');
const app = express();
const PORT = 5000;

// Load environment variables
require('dotenv').config();

// Endpoint to fetch places
app.get('/api/places', async (req, res) => {
  const { location, type } = req.query;
  const apiKey = process.env.GOOGLE_PLACES_API_KEY; // Ensure this is set in your .env file

  if (!location || !type) {
    return res.status(400).json({ message: "Location and type are required" });
  }

  try {
    const response = await axios.get('https://maps.googleapis.com/maps/api/place/textsearch/json', {
      params: {
        query: `${type} in ${location}`,
        key: apiKey,
      },
    });

    // Map the response for easier frontend processing
    const results = response.data.results.map((place) => ({
      name: place.name,
      address: place.formatted_address,
      rating: place.rating,
      photoUrl: place.photos?.[0]?.photo_reference
        ? `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${place.photos[0].photo_reference}&key=${apiKey}`
        : null,
    }));

    res.json({ results });
  } catch (error) {
    console.error("Error fetching places data:", error.message);
    res.status(500).json({ message: "Error fetching places data" });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
